//window.alert("testing to see if linked");

console.log("testing to see if linked log");

//var is the declaration of a variable
//"name" is the name of the variable
var name="Janlu";
var job;
var salary;
//var name, job;
//Variable are containers that store data

console.log(job);

job="Developer";
salary= 25000;

// Data types for javaScript - numbers, strings, boolean, undefine and null

console.log(job);

//variables can't start with a number(use undetscre)
//var 1student;
var _1student;

//javaScript is Case sensitive
var student;
var Student;

window.alert("HELLO WORLD!!")
